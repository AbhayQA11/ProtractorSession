describe('First Test',function(){
    it('spec',function(){
        browser.get("https://juliemr.github.io/protractor-demo/")
        browser.sleep(5000);
    })

    it('verifying the title',function(){
        expect(browser.getTitle()).toBe('Super Calculator');
    })

    it('add 2 numbers',function(){
        element(by.model("first")).sendKeys('2');
        element(by.model("second")).sendKeys('2');
        element(by.id("gobutton")).click();
        browser.sleep(5000);
    })
})