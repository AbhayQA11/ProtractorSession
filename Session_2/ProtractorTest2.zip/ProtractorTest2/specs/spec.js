var calcPage = require('../pages/calcPage');
var testData = require('../testData');
var using = require('jasmine-data-provider');
describe('First Test',function(){

    beforeAll(function(){
        return browser.get("https://juliemr.github.io/protractor-demo/")
    })

    it('verifying the title',function(){
        expect(browser.getTitle()).toBe('Super Calculator');
    })
    using(testData.specData, function(data){
        it('add 2 numbers',async function(){
            calcPage.add(data.num1,data.num2);
            // expect(element(by.tagName('h2')).getText()).
            // toEqual(data.num3);
            browser.sleep(3000);
        })
    })


    // it('subtract two number', function(){
    //     element(by.model("first")).sendKeys('6');
    //     element(by.cssContainingText('option', '-')).click();
    //     element(by.model("second")).sendKeys('2');
    //     element(by.id("gobutton")).click();
    //     expect(element(by.binding('latest')).getText()).
    //     toEqual('4');
    //     browser.sleep(3000);
    // })
//     using(testData.specData, function(data){
//     it('multiply two number',async function(){
//         await element(by.model("first")).sendKeys(data.num1);
//         helper.selectDropdownbyNum(element(by.model("operator")),3);
//         await element(by.model("second")).sendKeys(data.num2);
//         await element(by.id("gobutton")).click();
//         await expect(element(by.binding('latest')).getText()).
//         toEqual(data.num3);
//     })
// })
})